/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nz.ac.aut.pdc.ChessHits.model.pieces;

import nz.ac.aut.pdc.ChessHits.model.*;

/**
 *
 * @author Yue Li
 * @version 24-07-13 class is built
 * @version 05-08-13 move method is completed
 */
public class Queen extends Piece {

    private final String STRING_REPRESENTATION = "Q";

    public Queen(int hitPoint, Position position, Color color) {
        super(hitPoint, position, color);
    }

    /**
     * move queen on the board
     *
     * @param board the resource board
     * @param position the target position
     * @return true if move is successful, false otherwise
     */
    @Override
    public boolean move(Position targetPosition) {
        boolean isMoveSuccessful = false;
        Position currentPos = super.getCurrentPosition();
        int columnDifference = targetPosition.getColumn() - super.getCurrentPosition().getColumn();
        int rowDifference = targetPosition.getRow() - super.getCurrentPosition().getRow();
        if (Math.abs(rowDifference) == Math.abs(columnDifference)) {//rowDifference == columnDifference || rowDifference + columnDifference == 0) {
            isMoveSuccessful = true;
        } else if (currentPos.getColumn() == targetPosition.getColumn() && currentPos.getRow() != targetPosition.getRow()
                || currentPos.getRow() == targetPosition.getRow() && currentPos.getColumn() != targetPosition.getColumn()) {
            isMoveSuccessful = true;
        }
//        Square currentSquare = board.getSquare(super.getCurrentPosition());
//        currentSquare.removePiece(this);
//        Square targetSquare = board.getSquare(targetPosition);
//        if (targetSquare.isSquareAvailable() && isMovingPositionOkay) {
//            targetSquare.addPiece(this);
//            isMoveSuccessful = true;
//        } else {
//            currentSquare.addPiece(this);
//        }
        return isMoveSuccessful;
    }

    /**
     * get queen's text representation
     *
     * @return string "Q" with color
     */
    @Override
    public String getStringRepresentation() {
        return super.determineColor() + this.STRING_REPRESENTATION;
    }
}
