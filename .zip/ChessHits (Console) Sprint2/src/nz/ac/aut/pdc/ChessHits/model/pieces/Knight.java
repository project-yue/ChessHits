/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nz.ac.aut.pdc.ChessHits.model.pieces;

import nz.ac.aut.pdc.ChessHits.model.Board;
import nz.ac.aut.pdc.ChessHits.model.Color;
import nz.ac.aut.pdc.ChessHits.model.Position;
import nz.ac.aut.pdc.ChessHits.model.Square;

/**
 *
 * @author Yue Li
 */
public class Knight extends Piece {

    private final String STRING_REPRESENTATION = "N";

    public Knight(int hitPoint, Position position, Color color) {
        super(hitPoint, position, color);
    }

    @Override
    public boolean move(Position targetPosition) {
        boolean isMoveSuccessful = false;
        int currentRow = super.getCurrentPosition().getRow();
        int currentCol = super.getCurrentPosition().getColumn();
        if (currentRow > targetPosition.getRow() && currentRow - targetPosition.getRow() == 2 && currentCol - targetPosition.getColumn() == 1 || currentCol - targetPosition.getColumn() == -1) {
            isMoveSuccessful = true;
        } else if (currentRow > targetPosition.getRow() && currentRow - targetPosition.getRow() == 1 && currentCol - targetPosition.getColumn() == 2 || currentCol - targetPosition.getColumn() == -1) {
            isMoveSuccessful = true;
        } else if (currentRow < targetPosition.getRow() && currentRow - targetPosition.getRow() == -1 && currentCol - targetPosition.getColumn() == 2 || currentCol - targetPosition.getColumn() == -2) {
            isMoveSuccessful = true;
        } else if (currentRow < targetPosition.getRow() && currentRow - targetPosition.getRow() == -2 && currentCol - targetPosition.getColumn() == 1 || currentCol - targetPosition.getColumn() == 2) {
            isMoveSuccessful = true;
        }
//        Square targetSquare = board.getSquare(targetPosition);
//        Square currentSquare = board.getSquare(super.getCurrentPosition());
//        currentSquare.removePiece(this);
//        if (isPositionOkay && targetSquare.isSquareAvailable()) {
//            targetSquare.addPiece(this);
//            isMoveSuccessful = true;
//        } else {
//            currentSquare.addPiece(this);
//        }
        return isMoveSuccessful;

    }

    @Override
    public String getStringRepresentation() {
        return super.determineColor() + this.STRING_REPRESENTATION;
    }
}
