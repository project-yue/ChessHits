/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nz.ac.aut.pdc.ChessHits.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import static nz.ac.aut.pdc.ChessHits.model.Color.BLACK;
import static nz.ac.aut.pdc.ChessHits.model.Color.WHITE;
import nz.ac.aut.pdc.ChessHits.model.pieces.*;

/**
 * the wrapper class of ChessHitsGame.
 *
 * @author Yue Li
 * @version 31-07-13 class is built, implemented Chess board initialization
 * @version 01-08-13 the initialization function is done. loading data should be
 * at the root directory of the project. the game class is able to read from txt
 * file.
 * @version 20-08-13 implemented draft move control.
 */
public class ChessHitsGame {

    // constants
    private static final String FILENAME = "SquareData.txt";
    // no function atm
    private Board board;
    private Player blackPlayer;
    private Player whitePlayer;

    /**
     * create a new game.
     */
    public ChessHitsGame() {
        this.board = new Board();
        initializePlayers();
        initializeGameFromFile(FILENAME);
        playerTurn(this.whitePlayer);
    }

    public Piece getPiece(Position position) {
        return board.getSquare(position).getOccupiedPiece();
    }

    public Board getBoard() {
        return this.board;
    }

    public final void playerTurn(Player player) {
        Position currentPosition = userInputForPiece(player, false);
        Position newPosition = userInputForPiece(player, true);
        //if the move is sucessful if not will repete untill valid
        if (!movePlayerPiece(currentPosition, newPosition)) {
            playerTurn(player);
        }

        Color tempColor = player.getSelectedColor();
        board.draw();
        switch (tempColor) {
            case WHITE:
                blackPlayer.setIsTurn(true);
                whitePlayer.setIsTurn(false);
                playerTurn(blackPlayer);
                break;
            case BLACK:
                blackPlayer.setIsTurn(false);
                whitePlayer.setIsTurn(true);
                playerTurn(whitePlayer);
        }
    }

    /**
     * determine if a piece can move to a position
     *
     * @param piece
     * @param fromPos
     * @param toPos
     * @return
     */
    private boolean canMove(Piece piece, Position fromPos, Position toPos) {
        boolean isSuccessful = false;
        String pieceName = piece.getStringRepresentation();
        char pieceRep = pieceName.charAt(1);
        switch (pieceRep) {
            case 'B':
                isSuccessful = areDiagonalPositionsOkayToMove(fromPos, toPos);
                break;
            case 'Q':
                isSuccessful = areVerticalOrHorizontalPositionsOkay(fromPos, toPos) || areDiagonalPositionsOkayToMove(fromPos, toPos);
                break;
            case 'K':
                isSuccessful = true;
                break;
            case 'R':
                isSuccessful = areVerticalOrHorizontalPositionsOkay(fromPos, toPos);
                break;
            case 'N':
                isSuccessful = true;
                break;
            case 'P':
                isSuccessful = true;
                break;
            default:
                System.err.println("piece is not selected correctly");
                break;
        }
        return isSuccessful;
    }

    /**
     * check diagonally if whether piece between 2 positions
     *
     * @param piece The piece to move
     * @param fromPos The current position
     * @param toPos The target position
     * @return true if there is no other piece blocking the way, false
     * otherwise.
     */
    private boolean areDiagonalPositionsOkayToMove(Position fromPos, Position toPos) {
        boolean isSuccessful = false;
        boolean isPositionAvaiable = true;
        // 4 possible directions
        int currentRow = fromPos.getRow(), currentCol = fromPos.getColumn(), targetRow = toPos.getRow(), targetCol = toPos.getColumn();
        int loop = Math.abs(currentRow - targetRow);//determine the loops
        int fromRow, fromCol;
        boolean isNEDirection = false, isSWDirection = false;
        if (currentRow > targetRow && currentCol > targetCol) {
            //NW okay
            fromRow = targetRow - 1;
            fromCol = targetCol - 1;
        } else if (currentRow > targetRow && currentCol < targetCol) {
            //NE okay
            fromRow = targetRow;
            fromCol = targetCol;
            isNEDirection = true;
        } else if (currentRow < targetRow && currentCol > targetCol) {
            //SW okay
            fromRow = targetRow;
            fromCol = targetCol;
            isSWDirection = true;
        } else {
            //SE okay
            fromRow = currentRow;
            fromCol = currentCol;
        }

        for (int r = loop; r > 0; r--) {
            Position testPosition;
            if (isNEDirection) {
                testPosition = this.board.getPositions()[fromRow++][fromCol--];
            } else if (isSWDirection) {
                testPosition = this.board.getPositions()[fromRow--][fromCol++];
            } else {
                testPosition = this.board.getPositions()[fromRow + r][fromCol + r];
            }
            if (!this.board.getSquare(testPosition).isSquareAvailable()) {
                isPositionAvaiable = false;
            }
        }
        if (isPositionAvaiable) {
            isSuccessful = true;
        }
        return isSuccessful;
    }

    private boolean areVerticalOrHorizontalPositionsOkay(Position fromPos, Position toPos) {
        boolean isSuccessful = false, isVertical = false, isHorizontal = false, isPositionAvaiable = true;
        int currentRow = fromPos.getRow(), currentCol = fromPos.getColumn(), targetRow = toPos.getRow(), targetCol = toPos.getColumn();
        int from = 0, to = 0, distanceLoopCounter = 0;
        if (currentRow == targetRow) {
            //horizontally
            if (currentCol > targetCol && currentCol != targetCol) {
                from = targetCol;
                to = currentCol;
            } else {
                from = currentCol;
                to = targetCol;
            }
            distanceLoopCounter = Math.abs(currentCol - targetCol);
            isHorizontal = true;
        } else if (currentCol == targetCol) {
            //vertically
            if (currentRow > targetRow) {
                from = targetRow;
                to = currentRow;
            } else {
                from = currentRow + 1;
                to = targetRow;
            }
            distanceLoopCounter = Math.abs(currentRow - targetRow);
            isVertical = true;
        }
        for (int r = distanceLoopCounter; r > 0; r--) {
            Position testPosition = null;
            if (isVertical) {
                testPosition = this.board.getPositions()[from++][currentCol];
            } else if (isHorizontal) {
                testPosition = this.board.getPositions()[currentRow][from++];
            }
            if (!this.board.getSquare(testPosition).isSquareAvailable()) {
                isPositionAvaiable = false;
            }
            if (isPositionAvaiable) {
                isSuccessful = true;
            }
        }
        return isSuccessful;
    }

    private void initializePlayers() {
        this.blackPlayer = new Player();
        this.whitePlayer = new Player();
        System.out.println("Please enter your user name (e.g. Yue):");
        Player player1 = new Player();
        player1.allocatePlayerName();
        System.out.println("Welcome to ChessHits, " + player1.getName());
        Color p1Color = player1.chooseColor();
        System.out.println("The other user, please enter your name (e.g. Guy)");
        Player player2 = new Player();
        player2.allocatePlayerName();
        System.out.println("Also welcome " + player2.getName());

        if (p1Color == Color.BLACK) {
            this.blackPlayer = player1;
            this.whitePlayer = player2;
        } else {
            this.whitePlayer = player1;
            this.blackPlayer = player2;
        }
        this.blackPlayer.setIsTurn(false);
        this.whitePlayer.setIsTurn(true);
        this.blackPlayer.setColor(Color.BLACK);
        this.whitePlayer.setColor(Color.WHITE);
    }

    /**
     * initialize Chessboard data from a txt file.
     *
     * @param filename name of resource file
     */
    private void initializeGameFromFile(String filename) {
        try {
            Scanner input = new Scanner(new File(filename));
            input.useDelimiter("\\s*,\\s*");
            generatePawns(Color.BLACK);
            generatePawns(Color.WHITE);
            generateRankPieces(Color.BLACK);
            generateRankPieces(Color.WHITE);
            board.draw();
        } catch (FileNotFoundException e) {
            System.err.println("unable to find the file " + filename);
        } catch (IOException e) {
            System.err.println("data of the file is corrupt");
        }
    }

    /**
     * generate pawn pieces for selected color.
     *
     * @param color the color for Pawn to be
     */
    private void generatePawns(Color color) {
        int row;
        if (color == Color.BLACK) {
            row = 6;
        } else {
            row = 1;
        }
        for (int col = 0; col < 8; col++) {
            Position temPosition = board.getPositions()[row][col];
            Square tempSquare = board.getSquare(temPosition);
            Piece pawn = new Pawn(3, temPosition, color);
            tempSquare.addPiece(pawn);
        }
    }

    /**
     * moves the players Piece to the new place and attacks a piece if it is in
     * its way
     *
     * @param currentPosition where the players piece is currently
     * @param newPosition where you want ot move the piece
     */
    private boolean movePlayerPiece(Position currentPosition, Position newPosition) {
        Piece piece = getPiece(currentPosition);
        Square targetSquare = board.getSquare(newPosition);
        Square currentSquare = board.getSquare(currentPosition);
        boolean hasMoved = false;
        // checking if it is a valid move and on the board
        if (piece.move(newPosition) && positionOnBoard(newPosition)) {
            //checking if the square is empty then will add the piece
            if (targetSquare.isSquareAvailable() && canMove(piece, currentPosition, newPosition)) {
                currentSquare.removePiece(piece);
                targetSquare.addPiece(piece);
                hasMoved = true;

            } //checks if the square is occupied then does a hit if the other piece is oppisition
            else if (getPiece(newPosition) != null && getPiece(newPosition).getColor() != piece.getColor()) {
                Piece pieceHit = getPiece(newPosition);
                piece.attack(pieceHit);
                System.out.println("you just hit a piece");
                hasMoved = true;

            } // invalid move
            else {
                System.out.println("sorry that move can not be done");
            }
        } else {
            System.out.println("sorry that move can not be done");
        }
        return hasMoved;

    }

    /**
     * generate higher rank pieces for selected color
     *
     * @param color the color for a set of pieces to be
     */
    private void generateRankPieces(Color color) {
        int row;
        if (color == Color.WHITE) {
            row = 0;
        } else {
            row = 7;
        }
        //rook init
        Position temPosition = board.getPositions()[row][0];
        Square temSquare = board.getSquare(temPosition);
        Rook rook1 = new Rook(2, temPosition, color);
        temSquare.addPiece(rook1);
        temPosition = board.getPositions()[row][7];
        temSquare = board.getSquare(temPosition);
        Rook rook2 = new Rook(2, temPosition, color);
        temSquare.addPiece(rook2);
        //knight initnir
        temPosition = board.getPositions()[row][1];
        Knight knight1 = new Knight(2, temPosition, color);
        temSquare = board.getSquare(temPosition);
        temSquare.addPiece(knight1);
        temPosition = board.getPositions()[row][6];
        Knight knight2 = new Knight(2, temPosition, color);
        temSquare = board.getSquare(temPosition);
        temSquare.addPiece(knight2);
        //bishop init
        temPosition = board.getPositions()[row][2];
        Bishop bishop1 = new Bishop(2, temPosition, color);
        temSquare = board.getSquare(temPosition);
        temSquare.addPiece(bishop1);
        temPosition = board.getPositions()[row][5];
        Bishop bishop2 = new Bishop(2, temPosition, color);
        temSquare = board.getSquare(temPosition);
        temSquare.addPiece(bishop2);
        //queen init
        temPosition = board.getPositions()[row][3];
        Queen queen = new Queen(1, temPosition, color);
        temSquare = board.getSquare(temPosition);
        temSquare.addPiece(queen);
        //king init
        temPosition = board.getPositions()[row][4];
        King king = new King(1, temPosition, color, true, true, true, true);
        temSquare = board.getSquare(temPosition);
        temSquare.addPiece(king);
    }

    private boolean positionOnBoard(Position position) {
        boolean isOnBoard = false;
        if (position.getRow() >= 0 && position.getColumn() >= 0
                && position.getColumn() <= 7 && position.getRow() <= 7) {

            isOnBoard = true;
        }
        return isOnBoard;
    }

    /**
     * for console version only the user input of the position and new position
     *
     */
    private Position userInputForPiece(Player player, Boolean isPieceSelected) {

        boolean moveDidntWorked = true;
        Position newPosition = null;
        while (moveDidntWorked) {
            try {
                newPosition = getUserMove(player, isPieceSelected);
                moveDidntWorked = false;


            } catch (Exception e) {
                // fix later will think about it 
                System.out.println("sorry that is not a valid position");
                moveDidntWorked = true;
            }
        }


        return newPosition;
    }

    private Position getUserMove(Player player, Boolean isPieceSelected) {
        int row, col;
        Position newPosition = null;
        boolean willLoop = true;

        while (willLoop) {
            Color color = player.getSelectedColor();
            String name = player.getName();
            if (!isPieceSelected) {
                System.out.println(name + " " + color + " please select a piece in row col e.g. 8 h ");
            } else {
                System.out.println(name + " " + color + " please select a New row col for piece e.g. 8 h ");
            }

            String tempUserInput;
            String[] inputContent;
            tempUserInput = new Scanner(System.in).nextLine();

            inputContent = tempUserInput.split(" ");
            row = convertToRow(inputContent[0]);
            col = convertToCol(inputContent[1]);
            willLoop = false;
            if (row < 0 || row > 7 || col < 0 || col > 7) {
                System.out.println("sorry position is not on the board");

                willLoop = true;
            }
            newPosition = board.getPositions()[row][col];

            if (!isPieceSelected) {
                Color piColor = board.getSquare(newPosition).getOccupiedPiece().getColor();
                if (board.getSquare(newPosition).isSquareAvailable()) {

                    System.out.println("sorry there is no piece there try again");

                    willLoop = true;
                }
                if (piColor != color) {
                    System.out.println("sorry that is not your piece");

                    willLoop = true;

                }
            }
        }

        return newPosition;
    }

    /**
     * convert column text representation to the value that java can manipulate
     *
     * @param letter The string representation of each column
     * @return an integer value
     */
    private int convertToCol(String letter) {
        int result = 10;
        switch (letter) {
            case "a":
                result = 0;
                break;
            case "b":
                result = 1;
                break;
            case "c":
                result = 2;
                break;
            case "d":
                result = 3;
                break;
            case "e":
                result = 4;
                break;
            case "f":
                result = 5;
                break;
            case "g":
                result = 6;
                break;
            case "h":
                result = 7;
                break;
        }
        return result;
    }

    /**
     * convert row text representation to the value that java can manipulate
     *
     * @param row The string representation of each row
     * @return an integer value
     */
    private int convertToRow(String row) {
        int exactRow = 10;
        switch (row) {
            case "8":
                exactRow = 0;
                break;
            case "7":
                exactRow = 1;
                break;
            case "6":
                exactRow = 2;
                break;
            case "5":
                exactRow = 3;
                break;
            case "4":
                exactRow = 4;
                break;
            case "3":
                exactRow = 5;
                break;
            case "2":
                exactRow = 6;
                break;
            case "1":
                exactRow = 7;
                break;
        }
        return exactRow;
    }
}
