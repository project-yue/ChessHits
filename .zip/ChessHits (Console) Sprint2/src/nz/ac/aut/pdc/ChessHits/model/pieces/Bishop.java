/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nz.ac.aut.pdc.ChessHits.model.pieces;

import nz.ac.aut.pdc.ChessHits.model.*;

/**
 *
 * @author Yue Li
 * @version 02-08-13 the implementation for move is done
 */
public class Bishop extends Piece {

    private final String STRING_REPRESENTATION = "B";

    /**
     * construct a Bishop object
     *
     * @param hitPoint the times of attack a bishop can take
     * @param position the initial position
     * @param color the resource color
     */
    public Bishop(int hitPoint, Position position, Color color) {
        super(hitPoint, position, color);
    }

    /**
     * move bishop to a target position on the board
     *
     * @param board the resource board
     * @param targetPosition the position bishop is moving to
     * @return true if bishop successfully moved, false otherwise
     */
    @Override
    public boolean move(Position targetPosition) {
        boolean isMoveSuccessful = false;
        int colTarget = targetPosition.getColumn() - getCurrentPosition().getColumn();
        int rowTarget = targetPosition.getRow() - getCurrentPosition().getRow();
        //checking if it can move
        if (Math.abs(colTarget) - Math.abs(rowTarget) == 0) {
            isMoveSuccessful = true;
            isMoveSuccessful = true;
        }

        return isMoveSuccessful;
    }

    /**
     * gets the string representation of bishop
     *
     * @return specified color with character B
     */
    @Override
    public String getStringRepresentation() {
        return super.determineColor() + this.STRING_REPRESENTATION;
    }
}
