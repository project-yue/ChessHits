/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nz.ac.aut.pdc.ChessHits.model.pieces;

import java.util.Scanner;
import nz.ac.aut.pdc.ChessHits.model.*;

/**
 * King is the most important piece in the game
 *
 * @author Yue Li
 * @version 24-07-13 class is built, abstract implementation done, probably not
 * the best time to do the move method, basic function is done.
 * @version 25-07-13 the move method implemented. yet to pass proper tests.
 * contains commented lines.
 * @version 2-08-13 add function for castling with a rook
 * @version 5-08-13 refined move method
 */
public class King extends Piece {

    private final String STRING_REPRESENTATION = "K";
    private boolean isChecked;
    private boolean isCheckmate;
    private boolean isStalemate;
    private boolean isAbleToCastle;

    /**
     * construct a king object
     *
     * @param hitPoint the times of attacks king can take
     * @param position the initial position king is
     * @param color the color of king
     * @param isNotChecked resource check status of king
     * @param isNotCheckmate resource checkmate status of king
     * @param isNotStalemate resource stalemate status of king
     * @param isAbleToCastle resource castle ability of king
     */
    public King(int hitPoint, Position position, Color color, boolean isNotChecked, boolean isNotCheckmate, boolean isNotStalemate, boolean isAbleToCastle) {
        super(hitPoint, position, color);
        this.isChecked = isNotChecked;
        this.isCheckmate = isNotCheckmate;
        this.isStalemate = isNotStalemate;
        this.isAbleToCastle = isAbleToCastle;
    }

    /**
     * get the check status of king. for situations when king is threaten by a
     * piece.
     *
     * @return true if king is threaten, false otherwise
     */
    public boolean getCheckStatus() {
        return this.isChecked;
    }

    /**
     * get the checkmate status of king. for situations when there is no legal
     * movement for king and king is threaten by a piece immediately.
     *
     * @return true if king is threaten and no other legal moves, false
     * otherwise
     */
    public boolean getCheckmateStatus() {
        return this.isCheckmate;
    }

    /**
     * get the stalemate status of king. for situation when there is a player's
     * turn but there is no legal movement
     *
     * @return true if player has no legal moves available, false otherwise
     */
    public boolean getStalemateStatus() {
        return this.isStalemate;
    }

    /**
     * get the castle status of king
     *
     * @return true if king is able to perform a castle, false otherwise
     */
    public boolean getCastleStatus() {
        return this.isAbleToCastle;
    }

    /**
     * disable the ability of castling
     */
    public void disableCastle() {
        this.isAbleToCastle = false;
    }

    /**
     * enable the ability of castling
     */
    public void enableCastle() {
        this.isAbleToCastle = true;
    }

    public boolean performCastling() {
        boolean isPerformed = false;
        if (this.getCastleStatus()) {
            Scanner input = new Scanner(System.in);
            System.out.println("Would you wish to perform castling?(y/n)"); //can be replaced by do while loop?
            String userAnwser = input.next();
            if (userAnwser.equals("y")) {
                
            }
        }
        return isPerformed;
    }

    /**
     * move King to a new position on the board
     *
     * @param board The resource board
     * @param targetPosition The target position
     * @return true if move is legal, false otherwise
     */
    @Override
    public boolean move(Position targetPosition) {
        boolean isMoveSucessful = false;
        int horizontalDifference = targetPosition.getColumn() - super.getCurrentPosition().getColumn();
        int verticalDifference = targetPosition.getRow() - super.getCurrentPosition().getRow();

        if (horizontalDifference >= -1 && horizontalDifference <= 1 && verticalDifference >= -1 && verticalDifference <= 1) {
            
            isMoveSucessful = true;
        }

    //        Square targetSquare = board.getSquare(targetPosition);
    //        Square currentSquare = board.getSquare(super.getCurrentPosition());
    //        if (targetSquare.isSquareAvailable() && isMovingPositionOkay) {
    //            targetSquare.addPiece(this);
    //            currentSquare.removePiece(this);
    //            isMoveSucessful = true;
    //            disableCastle();
    //        } else {
    //            currentSquare.addPiece(this);
    //        }
      //  System.out.println(horizontalDifference + " " + verticalDifference);
        return isMoveSucessful;
    }

    /**
     * string representation
     *
     * @return piece's color+"K"
     */
    @Override
    public String getStringRepresentation() {
        return super.determineColor() + this.STRING_REPRESENTATION;
    }
}
