/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nz.ac.aut.pdc.ChessHits.model.pieces;

import nz.ac.aut.pdc.ChessHits.model.Board;
import nz.ac.aut.pdc.ChessHits.model.Color;
import nz.ac.aut.pdc.ChessHits.model.Position;
import nz.ac.aut.pdc.ChessHits.model.Square;

/**
 * Rook can move vertically or horizontally on chessboard
 *
 * @author Yue Li
 * @version 31-07-13 class is built. move method implemented
 */
public class Rook extends Piece {

    private final String STRING_REPRESENTATION = "R";
    private boolean isAbleToCastle;

    public Rook(int hitPoint, Position position, Color color) {
        super(hitPoint, position, color);
        this.isAbleToCastle = true;
    }

    @Override
    public boolean move(Position targetPosition) {
        boolean isMoveSuccessful = false;
        Position currentPos = super.getCurrentPosition();
        if (currentPos.getColumn() == targetPosition.getColumn() && currentPos.getRow() != targetPosition.getRow()
                || currentPos.getRow() == targetPosition.getRow() && currentPos.getColumn() != targetPosition.getColumn()) {
            isMoveSuccessful = true;
        }
//        Square currentSquare = board.getSquare(currentPos);
//        Square targetSquare = board.getSquare(targetPosition);
//        currentSquare.removePiece(this);
//        if (targetSquare.isSquareAvailable() && isMovingPositionOkay) {
//            targetSquare.addPiece(this);
//            isMoveSuccessful = true;
//        } else {
//            currentSquare.addPiece(this);
//        }
        return isMoveSuccessful;
    }

    public void disableCastle() {
        this.isAbleToCastle = false;
    }

    public void enableCastle() {
        this.isAbleToCastle = true;
    }

    public boolean getCastleStatus() {
        return this.isAbleToCastle;
    }

    @Override
    public String getStringRepresentation() {
        return super.determineColor() + this.STRING_REPRESENTATION;
    }
}
